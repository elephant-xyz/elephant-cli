const fs = require('fs');
const path = require('path');
const cheerio = require('cheerio');

/**
 * Parse a polygon string from CSV and convert to new format
 * @param {string} polygonStr - Polygon string from CSV
 * @returns {Array<{latitude: number, longitude: number}>|null} - Parsed polygon or null
 */
function parsePolygonFromString(polygonStr) {
  if (!polygonStr) return null;
  
  // Remove outer quotes if present
  const cleanedStr = polygonStr.trim().replace(/^["']+|["']+$/g, '');
  if (!cleanedStr || cleanedStr.length === 0) return null;
  
  try {
    const parsed = JSON.parse(cleanedStr);
    
    // Handle old format: [[[lon, lat], [lon, lat], ...]]
    if (Array.isArray(parsed) && Array.isArray(parsed[0]) && Array.isArray(parsed[0][0])) {
      // Convert from [[[lon, lat], ...]] to [{latitude: lat, longitude: lon}, ...]
      const coords = parsed[0]; // Get first ring
      if (coords.length >= 3) {
        const polygon = coords.map(coord => {
          if (Array.isArray(coord) && coord.length >= 2) {
            return {
              latitude: coord[1], // lat is second element
              longitude: coord[0]  // lon is first element
            };
          }
          return null;
        }).filter(c => c !== null);
        
        if (polygon.length >= 3) {
          return polygon;
        }
      }
      return null;
    } else if (Array.isArray(parsed)) {
      // Check if already in new format: [{latitude: lat, longitude: lon}, ...]
      if (parsed.length >= 3 && parsed[0] && typeof parsed[0] === 'object' && 'latitude' in parsed[0] && 'longitude' in parsed[0]) {
        return parsed;
      } else {
        // Try to convert if it's [[lon, lat], ...] format
        if (parsed.length >= 3 && Array.isArray(parsed[0]) && parsed[0].length >= 2) {
          return parsed.map(coord => ({
            latitude: coord[1],
            longitude: coord[0]
          }));
        }
      }
    }
    return null;
  } catch (error) {
    console.error('Error parsing polygon from CSV:', error.message);
    console.error('Polygon string (first 100 chars):', cleanedStr.substring(0, 100));
    return null;
  }
}

/**
 * Extract geometry information from CSV
 * Returns three separate geometry objects: address (lat/long only), parcel (parcel_polygon), and building (building_polygon)
 * @param {string} csvPath - Path to CSV file
 * @param {string} requestIdentifier - Request identifier from seed
 * @returns {object|null} - Object with addressGeometry, parcelGeometry, and buildingGeometry properties, or null
 */
function extractGeometryFromCsv(csvPath, requestIdentifier) {
  if (!fs.existsSync(csvPath)) {
    return null;
  }
  
  const csvContent = fs.readFileSync(csvPath, 'utf8');
  const lines = csvContent.split('\n').filter(line => line.trim());
  if (lines.length < 2) {
    return null;
  }
  
  // Parse CSV header - use proper CSV parsing for headers too
  const parseCsvRow = (row) => {
    const result = [];
    let current = '';
    let inQuotes = false;
    let escaped = false;
    
    for (let i = 0; i < row.length; i++) {
      const char = row[i];
      
      if (escaped) {
        current += char;
        escaped = false;
        continue;
      }
      
      if (char === '\\') {
        escaped = true;
        current += char;
        continue;
      }
      
      if (char === '"') {
        // Handle escaped quotes within quoted strings
        if (inQuotes && i + 1 < row.length && row[i + 1] === '"') {
          current += '"';
          i++; // Skip next quote
          continue;
        }
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        result.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
    result.push(current.trim());
    return result;
  };
  
  // Parse headers
  const headers = parseCsvRow(lines[0]).map(h => h.replace(/^["']|["']$/g, '').trim());
  const dataLine = lines[1];
  
  // Find indices for relevant columns
  const parcelPolygonIdx = headers.indexOf('parcel_polygon');
  const buildingPolygonIdx = headers.indexOf('building_polygon');
  const longitudeIdx = headers.indexOf('longitude');
  const latitudeIdx = headers.indexOf('latitude');
  
  if (parcelPolygonIdx === -1 && buildingPolygonIdx === -1 && longitudeIdx === -1 && latitudeIdx === -1) {
    return null;
  }
  
  // Parse CSV data row
  const values = parseCsvRow(dataLine);
  
  let latitude = null;
  let longitude = null;
  let parcelPolygon = null;
  let buildingPolygon = null;
  
  // Extract latitude/longitude (for address geometry)
  if (latitudeIdx !== -1 && values[latitudeIdx]) {
    const lat = parseFloat(values[latitudeIdx]);
    if (!isNaN(lat) && lat >= -90 && lat <= 90) {
      latitude = lat;
    }
  }
  
  if (longitudeIdx !== -1 && values[longitudeIdx]) {
    const lon = parseFloat(values[longitudeIdx]);
    if (!isNaN(lon) && lon >= -180 && lon <= 180) {
      longitude = lon;
    }
  }
  
  // Extract parcel polygon
  if (parcelPolygonIdx !== -1 && parcelPolygonIdx < values.length) {
    parcelPolygon = parsePolygonFromString(values[parcelPolygonIdx]);
    if (parcelPolygon) {
      console.log(`✓ Parsed parcel polygon with ${parcelPolygon.length} points from CSV`);
    }
  }
  
  // Extract building polygon
  if (buildingPolygonIdx !== -1 && buildingPolygonIdx < values.length) {
    buildingPolygon = parsePolygonFromString(values[buildingPolygonIdx]);
    if (buildingPolygon) {
      console.log(`✓ Parsed building polygon with ${buildingPolygon.length} points from CSV`);
    }
  }
  
  // Create three separate geometry objects
  const result = {
    addressGeometry: null,
    parcelGeometry: null,
    buildingGeometry: null
  };
  
  // Address geometry: only lat/long (no polygon)
  if (latitude !== null || longitude !== null) {
    result.addressGeometry = {
      request_identifier: requestIdentifier,
      latitude: latitude,
      longitude: longitude,
      // No polygon for address geometry (polygon field not included)
    };
  }
  
  // Parcel geometry: parcel_polygon only (no lat/long)
  if (parcelPolygon && Array.isArray(parcelPolygon) && parcelPolygon.length >= 3) {
    result.parcelGeometry = {
      request_identifier: requestIdentifier,
      latitude: null,
      longitude: null,
      polygon: parcelPolygon,
    };
  }
  
  // Building geometry: building_polygon only (no lat/long)
  if (buildingPolygon && Array.isArray(buildingPolygon) && buildingPolygon.length >= 3) {
    result.buildingGeometry = {
      request_identifier: requestIdentifier,
      latitude: null,
      longitude: null,
      polygon: buildingPolygon,
    };
  }
  
  // Return null if no geometries were created
  if (!result.addressGeometry && !result.parcelGeometry && !result.buildingGeometry) {
    return null;
  }
  
  return result;
}

function ensureDir(p) {
  if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true });
}

function readJSON(p) {
  return JSON.parse(fs.readFileSync(p, 'utf-8'));
}

function cleanText(t) {
  return (t || '')
    .replace(/\u00A0/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function parseNumber(str) {
  if (str == null) return null;
  const s = ('' + str).replace(/[$,]/g, '').trim();
  if (s === '' || s === '-') return null;
  const n = Number(s);
  return isNaN(n) ? null : n;
}

function parseDateMMDDYYYY(mmddyyyy) {
  if (!mmddyyyy) return null;
  const parts = mmddyyyy.trim().split('/');
  if (parts.length !== 3) return null;
  const [MM, DD, YYYY] = parts;
  if (!YYYY || !MM || !DD) return null;
  const mm = MM.padStart(2, '0');
  const dd = DD.padStart(2, '0');
  return `${YYYY}-${mm}-${dd}`;
}

function writeJSON(filePath, obj) {
  fs.writeFileSync(filePath, JSON.stringify(obj, null, 2));
}

function normalizeSpaceType(value) {
  if (value == null) return null;
  const allowed = [
    "Living Room",
    "Family Room",
    "Great Room",
    "Dining Room",
    "Kitchen",
    "Breakfast Nook",
    "Pantry",
    "Primary Bedroom",
    "Secondary Bedroom",
    "Guest Bedroom",
    "Children’s Bedroom",
    "Nursery",
    "Full Bathroom",
    "Three-Quarter Bathroom",
    "Half Bathroom / Powder Room",
    "En-Suite Bathroom",
    "Jack-and-Jill Bathroom",
    "Primary Bathroom",
    "Laundry Room",
    "Mudroom",
    "Closet",
    "Bedroom",
    "Walk-in Closet",
    "Mechanical Room",
    "Storage Room",
    "Server/IT Closet",
    "Home Office",
    "Library",
    "Den",
    "Study",
    "Media Room / Home Theater",
    "Game Room",
    "Home Gym",
    "Music Room",
    "Craft Room / Hobby Room",
    "Prayer Room / Meditation Room",
    "Safe Room / Panic Room",
    "Wine Cellar",
    "Bar Area",
    "Greenhouse",
    "Attached Garage",
    "Detached Garage",
    "Carport",
    "Workshop",
    "Storage Loft",
    "Porch",
    "Screened Porch",
    "Sunroom",
    "Deck",
    "Patio",
    "Pergola",
    "Balcony",
    "Terrace",
    "Gazebo",
    "Pool House",
    "Outdoor Kitchen",
    "Lobby / Entry Hall",
    "Common Room",
    "Utility Closet",
    "Elevator Lobby",
    "Mail Room",
    "Janitor’s Closet",
    "Pool Area",
    "Indoor Pool",
    "Outdoor Pool",
    "Hot Tub / Spa Area",
    "Shed",
    null
  ].filter(v => v !== null);
  const s = cleanText(String(value));
  if (!s) return null;
  const lower = s.toLowerCase();

  // Exact match against allowed (case-insensitive)
  for (const a of allowed) {
    if (a.toLowerCase() === lower) return a;
  }

  // Normalize straight/curly quotes and common punctuation
  const norm = lower
    .replace(/[’']/g, "'")
    .replace(/\s+/g, ' ')
    .trim();

  const map = new Map([
    // Rooms
    ['living', 'Living Room'],
    ['living room', 'Living Room'],
    ['livingroom', 'Living Room'],

    ['family', 'Family Room'],
    ['family room', 'Family Room'],

    ['great room', 'Great Room'],
    ['greatroom', 'Great Room'],

    ['dining', 'Dining Room'],
    ['dining room', 'Dining Room'],
    ['dining area', 'Dining Room'],

    ['kitchen', 'Kitchen'],

    ['breakfast', 'Breakfast Nook'],
    ['breakfast nook', 'Breakfast Nook'],
    ['nook', 'Breakfast Nook'],

    ['pantry', 'Pantry'],

    ['primary bedroom', 'Primary Bedroom'],
    ['master bedroom', 'Primary Bedroom'],
    ['owner\'s suite', 'Primary Bedroom'],
    ['owners suite', 'Primary Bedroom'],
    ['primary suite', 'Primary Bedroom'],
    ['main bedroom', 'Primary Bedroom'],

    ['secondary bedroom', 'Secondary Bedroom'],

    ['guest bedroom', 'Guest Bedroom'],
    ['guest room', 'Guest Bedroom'],

    ["children's bedroom", 'Children’s Bedroom'],
    ['childrens bedroom', 'Children’s Bedroom'],
    ['children’s bedroom', 'Children’s Bedroom'],
    ['kids bedroom', 'Children’s Bedroom'],
    ['child bedroom', 'Children’s Bedroom'],

    ['nursery', 'Nursery'],

    ['full bath', 'Full Bathroom'],
    ['full bathroom', 'Full Bathroom'],
    ['bathroom (full)', 'Full Bathroom'],

    ['three-quarter bathroom', 'Three-Quarter Bathroom'],
    ['three quarter bathroom', 'Three-Quarter Bathroom'],
    ['three-quarter bath', 'Three-Quarter Bathroom'],
    ['three quarter bath', 'Three-Quarter Bathroom'],
    ['3/4 bath', 'Three-Quarter Bathroom'],

    ['half bath', 'Half Bathroom / Powder Room'],
    ['powder room', 'Half Bathroom / Powder Room'],
    ['half bathroom', 'Half Bathroom / Powder Room'],

    ['en suite bathroom', 'En-Suite Bathroom'],
    ['en-suite bathroom', 'En-Suite Bathroom'],
    ['ensuite bathroom', 'En-Suite Bathroom'],
    ['ensuite', 'En-Suite Bathroom'],
    ['en suite', 'En-Suite Bathroom'],

    ['jack and jill bathroom', 'Jack-and-Jill Bathroom'],
    ['jack & jill bathroom', 'Jack-and-Jill Bathroom'],
    ['jack-and-jill bathroom', 'Jack-and-Jill Bathroom'],

    ['primary bathroom', 'Primary Bathroom'],
    ['master bathroom', 'Primary Bathroom'],
    ['primary bath', 'Primary Bathroom'],
    ['master bath', 'Primary Bathroom'],

    ['laundry', 'Laundry Room'],
    ['laundry room', 'Laundry Room'],
    ['wash room', 'Laundry Room'],

    ['mudroom', 'Mudroom'],
    ['mud room', 'Mudroom'],

    ['closet', 'Closet'],
    ['walk-in closet', 'Walk-in Closet'],
    ['walk in closet', 'Walk-in Closet'],

    ['mechanical', 'Mechanical Room'],
    ['mechanical room', 'Mechanical Room'],
    ['mech room', 'Mechanical Room'],

    ['storage', 'Storage Room'],
    ['storage room', 'Storage Room'],

    ['server closet', 'Server/IT Closet'],
    ['it closet', 'Server/IT Closet'],
    ['server/it closet', 'Server/IT Closet'],

    ['home office', 'Home Office'],
    ['office', 'Home Office'],

    ['library', 'Library'],

    ['den', 'Den'],

    ['study', 'Study'],

    ['media room', 'Media Room / Home Theater'],
    ['home theater', 'Media Room / Home Theater'],
    ['home theatre', 'Media Room / Home Theater'],
    ['theater room', 'Media Room / Home Theater'],
    ['theatre room', 'Media Room / Home Theater'],

    ['game room', 'Game Room'],
    ['gameroom', 'Game Room'],

    ['home gym', 'Home Gym'],
    ['gym', 'Home Gym'],
    ['exercise room', 'Home Gym'],
    ['fitness room', 'Home Gym'],

    ['music room', 'Music Room'],

    ['craft room', 'Craft Room / Hobby Room'],
    ['hobby room', 'Craft Room / Hobby Room'],
    ['craft/hobby room', 'Craft Room / Hobby Room'],

    ['prayer room', 'Prayer Room / Meditation Room'],
    ['meditation room', 'Prayer Room / Meditation Room'],
    ['prayer/meditation room', 'Prayer Room / Meditation Room'],

    ['safe room', 'Safe Room / Panic Room'],
    ['panic room', 'Safe Room / Panic Room'],

    ['wine cellar', 'Wine Cellar'],

    ['bar area', 'Bar Area'],
    ['bar', 'Bar Area'],
    ['wet bar', 'Bar Area'],

    ['greenhouse', 'Greenhouse'],

    ['attached garage', 'Attached Garage'],
    ['garage', 'Attached Garage'], // default to attached when unspecified
    ['detached garage', 'Detached Garage'],

    ['carport', 'Carport'],

    ['workshop', 'Workshop'],

    ['storage loft', 'Storage Loft'],
    ['loft storage', 'Storage Loft'],

    ['porch', 'Porch'],
    ['front porch', 'Porch'],

    ['screened porch', 'Screened Porch'],
    ['screen porch', 'Screened Porch'],
    ['screened lanai', 'Screened Porch'],
    ['lanai', 'Screened Porch'],

    ['sunroom', 'Sunroom'],
    ['sun room', 'Sunroom'],
    ['florida room', 'Sunroom'],

    ['deck', 'Deck'],

    ['patio', 'Patio'],

    ['pergola', 'Pergola'],

    ['balcony', 'Balcony'],

    ['terrace', 'Terrace'],

    ['gazebo', 'Gazebo'],

    ['pool house', 'Pool House'],

    ['outdoor kitchen', 'Outdoor Kitchen'],
    ['summer kitchen', 'Outdoor Kitchen'],

    ['lobby', 'Lobby / Entry Hall'],
    ['entry', 'Lobby / Entry Hall'],
    ['entry hall', 'Lobby / Entry Hall'],
    ['foyer', 'Lobby / Entry Hall'],
    ['lobby / entry hall', 'Lobby / Entry Hall'],

    ['common room', 'Common Room'],
    ['community room', 'Common Room'],

    ['utility closet', 'Utility Closet'],
    ['electrical closet', 'Utility Closet'],

    ['elevator lobby', 'Elevator Lobby'],

    ['mail room', 'Mail Room'],
    ['mailroom', 'Mail Room'],

    ["janitor's closet", 'Janitor’s Closet'],
    ['janitors closet', 'Janitor’s Closet'],
    ['janitor’s closet', 'Janitor’s Closet'],

    ['pool area', 'Pool Area'],
    ['pool deck', 'Pool Area'],

    ['indoor pool', 'Indoor Pool'],

    ['outdoor pool', 'Outdoor Pool'],
    ['pool', 'Outdoor Pool'],

    ['hot tub', 'Hot Tub / Spa Area'],
    ['spa', 'Hot Tub / Spa Area'],
    ['jacuzzi', 'Hot Tub / Spa Area'],

    ['shed', 'Shed'],

    ['bedroom', 'Bedroom']
  ]);

  if (map.has(norm)) return map.get(norm);

  // Not recognized; return null to satisfy schema
  return null;
}

function extractProperty($) {
  // parcel_identifier (STRAP)
  const parcelLabel = $('#parcelLabel').text();
  let parcelIdentifier = null;
  const strapMatch = parcelLabel.match(/STRAP:\s*([^\s]+)\s*/i);
  if (strapMatch) parcelIdentifier = cleanText(strapMatch[1]);

  // legal description
  let legal = null;
  $('#PropertyDetailsCurrent')
    .find('.sectionSubTitle')
    .each((i, el) => {
      const t = cleanText($(el).text());
      if (/Property Description/i.test(t)) {
        const txt = cleanText($(el).next('.textPanel').text());
        if (txt) legal = txt.replace(/\s+/g, ' ').trim();
      }
    });
  if (!legal) {
    // fallback to the earlier property description section inside the top box
    const section = $('div.sectionSubTitle:contains("Property Description")');
    const txt = cleanText(section.next('.textPanel').text());
    if (txt) legal = txt;
  }
  if (legal) {
    // normalize spacing
    legal = legal.replace(/\s{2,}/g, ' ');
  }

  // Gross Living Area: prefer explicit th contains selector
  let gla = null;
  const glaTh = $('th:contains("Gross Living Area")').first();
  if (glaTh.length) {
    const td = glaTh.closest('tr').find('td').first();
    gla = cleanText(td.text());
  }
  if (!gla) {
    // alternate scan
    $('table.appraisalDetails').each((i, tbl) => {
      $(tbl)
        .find('tr')
        .each((j, tr) => {
          const th = cleanText($(tr).find('th').first().text());
          if (/Gross Living Area/i.test(th)) {
            const td = $(tr).find('td').first();
            const val = cleanText(td.text());
            if (val) gla = val;
          }
        });
    });
  }

  // Year Built (1st Year Building on Tax Roll)
  let yearBuilt = null;
  const ybTh = $('th:contains("1st Year Building on Tax Roll")').first();
  if (ybTh.length) {
    const td = ybTh.closest('tr').find('td').first();
    yearBuilt = parseNumber(td.text());
  }
  if (!yearBuilt) {
    $('table.appraisalAttributes')
      .find('tr')
      .each((i, tr) => {
        const ths = $(tr).find('th');
        if (
          ths.length === 4 &&
          /Bedrooms/i.test(cleanText($(ths[0]).text())) &&
          /Year Built/i.test(cleanText($(ths[2]).text()))
        ) {
          const next = $(tr).next();
          const cells = next.find('td');
          if (cells.length >= 3) {
            const y = parseNumber($(cells[2]).text());
            if (y) yearBuilt = y;
          }
        }
      });
  }

  // Subdivision from legal description prefix
  let subdivision = null;
  if (legal) {
    const m =
      legal.match(/^([^,\n]+?SEC\s*\d+)/i) ||
      legal.match(/^([^\n]+?)(?:\s{2,}|\s+PB\b)/i) ||
      legal.match(/^([^\n]+?)(?:\s{2,}|\s+)/);
    if (m) subdivision = cleanText(m[1]);
  }

  // ENHANCED PROPERTY TYPE EXTRACTION
  let livingUnits = null;
  let modelType = null;
  let rawModelType = null;

  // Extract living units and model type from building characteristics
  $('table.appraisalAttributes').each((_, table) => {
    const rows = $(table).find('tr');
    rows.each((i, row) => {
      const cells = $(row).find('td, th');
      if (cells.length >= 2) {
        const header = cleanText($(cells[0]).text()).toLowerCase();
        if (header.includes('living units')) {
          if (i + 1 < rows.length) {
            const dataRow = $(rows[i + 1]);
            const dataCells = dataRow.find('td, th');
            if (dataCells.length >= 4) {
              try {
                livingUnits = parseInt(cleanText($(dataCells[3]).text()));
              } catch (e) {}
            }
          }
        } else if (header.includes('model type')) {
          if (i + 1 < rows.length) {
            const dataRow = $(rows[i + 1]);
            const dataCells = dataRow.find('td, th');
            if (dataCells.length >= 2) {
              rawModelType = cleanText($(dataCells[1]).text());
              modelType = rawModelType.toLowerCase();
            }
          }
        }
      }
    });
  });

  // Extract Use Code Description from Land Tracts table as fallback
  let useCodeDescription = null;
  let rawUseCodeDescription = null;

  const sections = $('#PropertyDetailsCurrent, #PropertyDetails');
  sections.each((_, section) => {
    $(section).find('table.appraisalAttributes').each((_, table) => {
      $(table).find('tr').each((_, row) => {
        const cells = $(row).find('td, th');
        if (cells.length >= 1 && cleanText($(cells[0]).text()).toLowerCase().includes('land tracts')) {
          let headerRow = null;
          const dataRows = [];

          let currentRow = $(row).next();
          while (currentRow.length) {
            const rowCells = currentRow.find('td, th');
            if (!rowCells.length) break;

            if (rowCells.toArray().some(cell => cleanText($(cell).text()).toLowerCase().includes('use code description'))) {
              headerRow = currentRow;
            } else if (headerRow && rowCells.length) {
              dataRows.push(currentRow);
            } else if (dataRows.length > 0 && !rowCells.toArray().some(cell => cleanText($(cell).text()))) {
              break;
            }

            currentRow = currentRow.next();
          }

          if (headerRow && dataRows.length) {
            const headerCells = headerRow.find('td, th');
            const headers = headerCells.toArray().map(cell => cleanText($(cell).text()).toLowerCase());

            let descColIndex = null;
            headers.forEach((header, i) => {
              if (header.includes('use code description')) {
                descColIndex = i;
              }
            });

            if (descColIndex !== null && dataRows.length) {
              const firstDataRow = dataRows[0];
              const dataCells = firstDataRow.find('td, th');
              if (descColIndex < dataCells.length) {
                rawUseCodeDescription = cleanText($(dataCells[descColIndex]).text());
                useCodeDescription = rawUseCodeDescription.toLowerCase();

                console.log(`Use Code Description: "${rawUseCodeDescription}"`);
                console.log(`Use Code Description (lowercase): "${useCodeDescription}"`);

                return false;
              }
            }
          }
        }
      });
    });
  });

  // Map living units to number_of_units_type
  let numberOfUnitsType = 'One'; // default
  if (livingUnits) {
    if (livingUnits === 1) numberOfUnitsType = 'One';
    else if (livingUnits === 2) numberOfUnitsType = 'Two';
    else if (livingUnits === 3) numberOfUnitsType = 'Three';
    else if (livingUnits === 4) numberOfUnitsType = 'Four';
  }

  // Property type mapping function
function tryMapPropertyType(typeText, rawValue) {
  if (!typeText) return [null, null];

  let matched = null;
  const lowerText = typeText.toLowerCase();

  // Non-residential property codes - return raw value since they don't map to residential schema
  if (lowerText.includes('commercial, vacant') ||
      lowerText.includes('commercial, acreage') ||
      lowerText.includes('commercial, highway') ||
      lowerText.includes('professional, vacant') ||
      lowerText.includes('store, one') ||
      lowerText.includes('store, office, residential combinations') ||
      lowerText.includes('department store') ||
      lowerText.includes('supermarket') ||
      lowerText.includes('convenience store') ||
      lowerText.includes('shopping center') ||
      lowerText.includes('office building') ||
      lowerText.includes('manufacturing offices') ||
      lowerText.includes('professional building') ||
      lowerText.includes('medical office building') ||
      lowerText.includes('airport') ||
      lowerText.includes('marina') ||
      lowerText.includes('boat units') ||
      lowerText.includes('aircraft hangar') ||
      lowerText.includes('bus terminal') ||
      lowerText.includes('restaurant') ||
      lowerText.includes('financial institution') ||
      lowerText.includes('insurance company') ||
      lowerText.includes('service shop') ||
      lowerText.includes('laundry') ||
      lowerText.includes('laundromat') ||
      lowerText.includes('service station') ||
      lowerText.includes('vehicle lube/wash') ||
      lowerText.includes('auto sales') ||
      lowerText.includes('garage, repair') ||
      lowerText.includes('parking lot') ||
      lowerText.includes('trailer park sales') ||
      lowerText.includes('recreational vehicle park sales') ||
      lowerText.includes('wholesaler') ||
      lowerText.includes('produce house') ||
      lowerText.includes('florist') ||
      lowerText.includes('drive-in theatre') ||
      lowerText.includes('theatre') ||
      lowerText.includes('auditoriums') ||
      lowerText.includes('night club') ||
      lowerText.includes('bar, lounge') ||
      lowerText.includes('bowling alley') ||
      lowerText.includes('skating') ||
      lowerText.includes('hockey') ||
      lowerText.includes('ice rink') ||
      lowerText.includes('tourist attraction') ||
      lowerText.includes('camps') ||
      lowerText.includes('race track') ||
      lowerText.includes('golf course') ||
      lowerText.includes('motel') ||
      lowerText.includes('hotel') ||
      // Industrial codes
      lowerText.includes('industrial, vacant') ||
      lowerText.includes('light manufacturing') ||
      lowerText.includes('heavy manufacturing') ||
      lowerText.includes('exceptional industrial') ||
      lowerText.includes('lumber yard') ||
      lowerText.includes('packing plant') ||
      lowerText.includes('bottler') ||
      lowerText.includes('food processing') ||
      lowerText.includes('mineral processing') ||
      lowerText.includes('warehousing') ||
      lowerText.includes('open storage') ||
      // Agricultural codes
      lowerText.includes('field crop') ||
      lowerText.includes('vegetables') ||
      lowerText.includes('potatoes') ||
      lowerText.includes('miscellaneous ag land') ||
      lowerText.includes('sod') ||
      lowerText.includes('timber') ||
      lowerText.includes('pasture') ||
      lowerText.includes('grove') ||
      lowerText.includes('grapes') ||
      lowerText.includes('citrus nursery') ||
      lowerText.includes('bees') ||
      lowerText.includes('miscellaneous fowl') ||
      lowerText.includes('fish') ||
      lowerText.includes('horses') ||
      lowerText.includes('swine') ||
      lowerText.includes('goats') ||
      lowerText.includes('nursery, above ground') ||
      lowerText.includes('nursery, in ground') ||
      lowerText.includes('nursery, waste') ||
      lowerText.includes('aquaculture') ||
      // Institutional codes
      lowerText.includes('vacant institutional') ||
      lowerText.includes('church') ||
      lowerText.includes('school, private') ||
      lowerText.includes('day care centers') ||
      lowerText.includes('dormitory') ||
      lowerText.includes('hospital, private') ||
      lowerText.includes('nursing home') ||
      lowerText.includes('home for the aged') ||
      lowerText.includes('orphanage') ||
      lowerText.includes('mortuary') ||
      lowerText.includes('funeral home') ||
      lowerText.includes('cemetery') ||
      lowerText.includes('lodges') ||
      lowerText.includes('clubs') ||
      lowerText.includes('union halls') ||
      lowerText.includes('yachting clubs') ||
      lowerText.includes('boating associations') ||
      lowerText.includes('country clubs') ||
      lowerText.includes('sanitariums') ||
      lowerText.includes('cultural facilities') ||
      lowerText.includes('performing arts halls') ||
      // Government codes
      lowerText.includes('vacant governmental') ||
      lowerText.includes('military facility') ||
      lowerText.includes('government owned') ||
      lowerText.includes('county owned') ||
      lowerText.includes('state owned') ||
      lowerText.includes('federally owned') ||
      lowerText.includes('municipally owned') ||
      lowerText.includes('government owned') ||
      // Miscellaneous codes
      lowerText.includes('lease interest') ||
      lowerText.includes('no land interest') ||
      lowerText.includes('utilities') ||
      lowerText.includes('waterworks') ||
      lowerText.includes('mining') ||
      lowerText.includes('petroleum') ||
      lowerText.includes('phosphate') ||
      lowerText.includes('boat slips') ||
      lowerText.includes('right of way') ||
      lowerText.includes('submerged') ||
      lowerText.includes('low lot') ||
      lowerText.includes('lake') ||
      lowerText.includes('pond') ||
      lowerText.includes('bay bottom') ||
      lowerText.includes('borrow pit') ||
      lowerText.includes('waste land') ||
      lowerText.includes('sewer disp') ||
      lowerText.includes('solid waste') ||
      lowerText.includes('historical, privately owned') ||
      lowerText.includes('slough') ||
      lowerText.includes('indian mound') ||
      lowerText.includes('historical preserve') ||
      lowerText.includes('marsh lands') ||
      lowerText.includes('island') ||
      lowerText.includes('swamp') ||
      lowerText.includes('spoils easements') ||
      lowerText.includes('endangered species') ||
      lowerText.includes('eagles nests') ||
      lowerText.includes('mangrove') ||
      lowerText.includes('unbuildable') ||
      lowerText.includes('resource protect') ||
      lowerText.includes('wetlands') ||
      lowerText.includes('preserve') ||
      lowerText.includes('cypress head') ||
      lowerText.includes('hazardous waste sites') ||
      lowerText.includes('mineral rights') ||
      lowerText.includes('parks, privately owned') ||
      lowerText.includes('boat ramps') ||
      lowerText.includes('recreational areas') ||
      lowerText.includes('centrally assessed') ||
      lowerText.includes('acreage, non-agricultural') ||
      lowerText.includes('market value agricultural') ||
      lowerText.includes('market value conservation') ||
      lowerText.includes('acreage, exempt') ||
      lowerText.includes('acreage, buffer') ||
      lowerText.includes('conservation easement') ||
      lowerText.includes('acreage, rural') ||
      lowerText.includes('acreage, raw') ||
      lowerText.includes('acreage, beach front') ||
      lowerText.includes('acreage, highway')) {
    return [null, rawValue]; // Non-residential properties don't fit residential schema
  }

  // RESIDENTIAL Lee County Use Code Description mappings
  if (lowerText.includes('vacant residential')) {
    matched = 'VacantLand';
  }
  // Single Family Residential variations
  else if (lowerText.includes('single family residential')) {
    matched = 'SingleFamily';
  }
  // Mobile Home variations
  else if (lowerText.includes('mobile home subdivision') ||
           lowerText.includes('mobile home, elevated') ||
           lowerText.includes('mobile home park') ||
           lowerText.includes('mobile home, single family') ||
           lowerText.includes('mobile home, acreage') ||
           lowerText.includes('mobile home, waterfront') ||
           lowerText.includes('mobile home, canal')) {
    matched = 'MobileHome';
  }
  // RV and Mobile Home Condos
  else if (lowerText.includes('recreational vehicle park')) {
    matched = 'ManufacturedHousing';
  }
  else if (lowerText.includes('mobile home and rv condominiums')) {
    matched = 'Condominium';
  }
  // Multi-family 10+ units
  else if (lowerText.includes('multi-family, 10 or more units')) {
    matched = 'MultipleFamily';
  }
  // Multi-family less than 10 units (including waterfront variations)
  else if (lowerText.includes('multi-family, less than 10 units') ||
           lowerText.includes('multi family, less than 10 units') ||
           lowerText.includes('apartments')) {
    matched = 'TwoToFourFamily';
  }
  // Condominium variations
  else if (lowerText.includes('land condo') ||
           lowerText.includes('condominium reserve parcel')) {
    matched = 'Condominium';
  }
  // Interval Ownership/Time Share
  else if (lowerText.includes('interval ownership') ||
           lowerText.includes('interval ownership/time share')) {
    matched = 'Timeshare';
  }
  // Co-operative
  else if (lowerText.includes('co-operative')) {
    matched = 'Cooperative';
  }
  // Retirement Home
  else if (lowerText.includes('retirement home')) {
    matched = 'Retirement';
  }
  // Miscellaneous Residential
  else if (lowerText.includes('misc res') ||
           lowerText.includes('migrant camp') ||
           lowerText.includes('boarding house')) {
    matched = 'MiscellaneousResidential';
  }
  // General keyword matching (fallback for non-Lee County data)
  else if (['single family', 'single-family'].some(keyword => lowerText.includes(keyword))) {
    matched = 'SingleFamily';
  } else if (lowerText.includes('duplex') || lowerText.includes('2 unit') || lowerText.includes('two unit')) {
    matched = '2Units';
  } else if (lowerText.includes('triplex') || lowerText.includes('3 unit') || lowerText.includes('three unit')) {
    matched = '3Units';
  } else if (lowerText.includes('fourplex') || lowerText.includes('4 unit') || lowerText.includes('four unit')) {
    matched = '4Units';
  } else if (['townhouse', 'town house', 'townhome'].some(keyword => lowerText.includes(keyword))) {
    matched = 'Townhouse';
  } else if (lowerText.includes('condominium') || lowerText.includes('condo')) {
    if (lowerText.includes('detached')) {
      matched = 'DetachedCondominium';
    } else if (lowerText.includes('non warrantable') || lowerText.includes('nonwarrantable')) {
      matched = 'NonWarrantableCondo';
    } else {
      matched = 'Condominium';
    }
  } else if (lowerText.includes('cooperative') || lowerText.includes('co-op')) {
    matched = 'Cooperative';
  } else if (lowerText.includes('manufactured') || lowerText.includes('mobile') || lowerText.includes('trailer')) {
    if (['multi', 'double', 'triple', 'wide'].some(keyword => lowerText.includes(keyword))) {
      matched = 'ManufacturedHousingMultiWide';
    } else if (lowerText.includes('single wide')) {
      matched = 'ManufacturedHousingSingleWide';
    } else {
      matched = 'ManufacturedHousing';
    }
  } else if (lowerText.includes('modular')) {
    matched = 'Modular';
  } else if (['pud', 'planned unit', 'planned development'].some(keyword => lowerText.includes(keyword))) {
    matched = 'Pud';
  } else if (lowerText.includes('timeshare') || lowerText.includes('time share')) {
    matched = 'Timeshare';
  }

  return [matched, rawValue];
}

  let matchedType = null;
  let rawSourceValue = null;

  // Try Model Type first (Priority 1)
  if (modelType) {
    [matchedType, rawSourceValue] = tryMapPropertyType(modelType, rawModelType);
  }

  // If no match from Model Type, try Use Code Description (Priority 2)
  if (!matchedType && useCodeDescription) {
    [matchedType, rawSourceValue] = tryMapPropertyType(useCodeDescription, rawUseCodeDescription);
  }

  // If still no match, use living units as fallback (Priority 3)
  if (!matchedType && livingUnits) {
    if (livingUnits === 1) matchedType = 'SingleFamily';
    else if (livingUnits === 2) matchedType = '2Units';
    else if (livingUnits === 3) matchedType = '3Units';
    else if (livingUnits === 4) matchedType = '4Units';
    else if (livingUnits > 4) matchedType = 'MultipleFamily';
  }

  // Set the final property type
  let propertyType = matchedType || rawSourceValue || null;

  // Last resort: check section titles for property type
  if (!propertyType) {
    $('div.sectionSubTitle').each((_, title) => {
      const rawText = cleanText($(title).text()).toLowerCase();
      if (rawText.includes('condominium')) {
        propertyType = 'Condominium';
        return false;
      } else if (rawText.includes('townhouse')) {
        propertyType = 'Townhouse';
        return false;
      } else if (rawText.includes('single family') || rawText.includes('single-family')) {
        propertyType = 'SingleFamily';
        return false;
      }
    });
  }

  const property = {
    area_under_air: gla || null,
    livable_floor_area: gla || null,
    number_of_units_type: numberOfUnitsType,
    parcel_identifier: parcelIdentifier || null,
    property_legal_description_text: legal || null,
    property_structure_built_year: yearBuilt || null,
    property_type: propertyType || 'SingleFamily', // fallback to SingleFamily
    subdivision: subdivision || null,
  };
  return property;
}

function extractAddress($, unAddr) {
  // Site Address block
  const sitePanel = $('div.sectionSubTitle:contains("Site Address")').next(
    '.textPanel'
  );
  const lines = cleanText(sitePanel.html() || '')
    .replace(/<br\s*\/?>(\s*<br\s*\/?>)*/gi, '\n')
    .replace(/<[^>]+>/g, '')
    .split(/\n+/)
    .map((l) => cleanText(l))
    .filter(Boolean);

  let line1 = lines[0];
  let cityStateZip = lines[1] || '';

  // If no HTML address found, parse from unnormalized_address.json
  if (!line1 && unAddr && unAddr.full_address) {
    const addressParts = unAddr.full_address.split(',');
    if (addressParts.length >= 1) {
      line1 = addressParts[0].trim(); // Just the street part: "833 PUCCINI AVENUE SOUTH"
      if (addressParts.length >= 3) {
        // Just combine city with state zip: "LEHIGH ACRES FL 33974" (no comma)
        cityStateZip = addressParts[1].trim() + ' ' + addressParts[2].trim();
      }
    }
  }

  // Enhanced street parsing with directional and suffix mappings
  let street_number = null,
    street_name = null,
    street_suffix_type = null,
    street_pre_directional_text = null,
    street_post_directional_text = null;

  if (line1) {
    const parts = line1.split(/\s+/);
    street_number = parts.shift() || null;

    const directionalMappings = {
      'NORTH': 'N', 'SOUTH': 'S', 'EAST': 'E', 'WEST': 'W',
      'NORTHEAST': 'NE', 'NORTHWEST': 'NW', 'SOUTHEAST': 'SE', 'SOUTHWEST': 'SW',
      'N': 'N', 'S': 'S', 'E': 'E', 'W': 'W',
      'NE': 'NE', 'NW': 'NW', 'SE': 'SE', 'SW': 'SW'
    };

    const suffixMappings = {
      'STREET': 'St', 'ST': 'St',
        'AVENUE': 'Ave', 'AVE': 'Ave',
        'BOULEVARD': 'Blvd', 'BLVD': 'Blvd',
        'ROAD': 'Rd', 'RD': 'Rd',
        'LANE': 'Ln', 'LN': 'Ln',
        'DRIVE': 'Dr', 'DR': 'Dr',
        'COURT': 'Ct', 'CT': 'Ct',
        'PLACE': 'Pl', 'PL': 'Pl',
        'TERRACE': 'Ter', 'TER': 'Ter',
        'CIRCLE': 'Cir', 'CIR': 'Cir',
        'WAY': 'Way', 'LOOP': 'Loop',
        'PARKWAY': 'Pkwy', 'PKWY': 'Pkwy',
        'PLAZA': 'Plz', 'PLZ': 'Plz',
        'TRAIL': 'Trl', 'TRL': 'Trl',
        'BEND': 'Bnd', 'BND': 'Bnd',
        'CRESCENT': 'Cres', 'CRES': 'Cres',
        'MANOR': 'Mnr', 'MNR': 'Mnr',
        'SQUARE': 'Sq', 'SQ': 'Sq',
        'CROSSING': 'Xing', 'XING': 'Xing',
        'PATH': 'Path',  'RUN': 'Run',
        'WALK': 'Walk',  'ROW': 'Row',
        'ALLEY': 'Aly', 'ALY': 'Aly',
        'BEACH': 'Bch', 'BCH': 'Bch',
        'BRIDGE': 'Br', 'BRG': 'Br',
        'BROOK': 'Brk', 'BRK': 'Brk',
        'BROOKS': 'Brks', 'BRKS': 'Brks',
        'BUG': 'Bg', 'BG': 'Bg',
        'BUGS': 'Bgs', 'BGS': 'Bgs',
        'CLUB': 'Clb', 'CLB': 'Clb',
        'CLIFF': 'Clf', 'CLF': 'Clf',
        'CLIFFS': 'Clfs', 'CLFS': 'Clfs',
        'COMMON': 'Cmn', 'CMN': 'Cmn',
        'COMMONS': 'Cmns', 'CMNS': 'Cmns',
        'CORNER': 'Cor', 'COR': 'Cor',
        'CORNERS': 'Cors', 'CORS': 'Cors',
        'CREEK': 'Crk', 'CRK': 'Crk',
        'COURSE': 'Crse', 'CRSE': 'Crse',
        'CREST': 'Crst', 'CRST': 'Crst',
        'CAUSEWAY': 'Cswy', 'CSWY': 'Cswy',
        'COVE': 'Cv', 'CV': 'Cv',
        'CANYON': 'Cyn', 'CYN': 'Cyn',
        'DALE': 'Dl', 'DL': 'Dl',
        'DAM': 'Dm', 'DM': 'Dm',
        'DRIVES': 'Drs', 'DRS': 'Drs',
        'DIVIDE': 'Dv', 'DV': 'Dv',
        'ESTATE': 'Est', 'EST': 'Est',
        'ESTATES': 'Ests', 'ESTS': 'Ests',
        'EXPRESSWAY': 'Expy', 'EXPY': 'Expy',
        'EXTENSION': 'Ext', 'EXT': 'Ext',
        'EXTENSIONS': 'Exts', 'EXTS': 'Exts',
        'FALL': 'Fall', 'FALL': 'Fall',
        'FALLS': 'Fls', 'FLS': 'Fls',
        'FLAT': 'Flt', 'FLT': 'Flt',
        'FLATS': 'Flts', 'FLTS': 'Flts',
        'FORD': 'Frd', 'FRD': 'Frd',
        'FORDS': 'Frds', 'FRDS': 'Frds',
        'FORGE': 'Frg', 'FRG': 'Frg',
        'FORGES': 'Frgs', 'FRGS': 'Frgs',
        'FORK': 'Frk', 'FRK': 'Frk',
        'FORKS': 'Frks', 'FRKS': 'Frks',
        'FOREST': 'Frst', 'FRST': 'Frst',
        'FREEWAY': 'Fwy', 'FWY': 'Fwy',
        'FIELD': 'Fld', 'FLD': 'Fld',
        'FIELDS': 'Flds', 'FLDS': 'Flds',
        'GARDEN': 'Gdn', 'GDN': 'Gdn',
        'GARDENS': 'Gdns', 'GDNS': 'Gdns',
        'GLEN': 'Gln', 'GLN': 'Gln',
        'GLENS': 'Glns', 'GLNS': 'Glns',
        'GREEN': 'Grn', 'GRN': 'Grn',
        'GREENS': 'Grns', 'GRNS': 'Grns',
        'GROVE': 'Grv', 'GRV': 'Grv',
        'GROVES': 'Grvs', 'GRVS': 'Grvs',
        'GATEWAY': 'Gtwy', 'GTWY': 'Gtwy',
        'HARBOR': 'Hbr', 'HBR': 'Hbr',
        'HARBORS': 'Hbrs', 'HBRS': 'Hbrs',
        'HILL': 'Hl', 'HL': 'Hl',
        'HILLS': 'Hls', 'HLS': 'Hls',
        'HOLLOW': 'Holw', 'HOLW': 'Holw',
        'HEIGHTS': 'Hts', 'HTS': 'Hts',
        'HAVEN': 'Hvn', 'HVN': 'Hvn',
        'HIGHWAY': 'Hwy', 'HWY': 'Hwy',
        'INLET': 'Inlt', 'INLT': 'Inlt',
        'ISLAND': 'Is', 'IS': 'Is',
        'ISLANDS': 'Iss', 'ISS': 'Iss',
        'ISLE': 'Isle', 'SPUR': 'Spur',
        'JUNCTION': 'Jct', 'JCT': 'Jct',
        'JUNCTIONS': 'Jcts', 'JCTS': 'Jcts',
        'KNOLL': 'Knl', 'KNL': 'Knl',
        'KNOLLS': 'Knls', 'KNLS': 'Knls',
        'LOCK': 'Lck', 'LCK': 'Lck',
        'LOCKS': 'Lcks', 'LCKS': 'Lcks',
        'LODGE': 'Ldg', 'LDG': 'Ldg',
        'LIGHT': 'Lgt', 'LGT': 'Lgt',
        'LIGHTS': 'Lgts', 'LGTS': 'Lgts',
        'LAKE': 'Lk', 'LK': 'Lk',
        'LAKES': 'Lks', 'LKS': 'Lks',
        'LANDING': 'Lndg', 'LNDG': 'Lndg',
        'MALL': 'Mall', 'MEWS': 'Mews',
        'MEADOW': 'Mdw', 'MDW': 'Mdw',
        'MEADOWS': 'Mdws', 'MDWS': 'Mdws',
        'MILL': 'Ml', 'ML': 'Ml',
        'MILLS': 'Mls', 'MLS': 'Mls',
        'MANORS': 'Mnrs', 'MNRS': 'Mnrs',
        'MOUNT': 'Mt', 'MT': 'Mt',
        'MOUNTAIN': 'Mtn', 'MTN': 'Mtn',
        'MOUNTAINS': 'Mtns', 'MTNS': 'Mtns',
        'OVERPASS': 'Opas', 'OPAS': 'Opas',
        'ORCHARD': 'Orch', 'ORCH': 'Orch',
        'OVAL': 'Oval', 'PARK': 'Park',
        'PASS': 'Pass', 'PIKE': 'Pike',
        'PLAIN': 'Pln', 'PLN': 'Pln',
        'PLAINS': 'Plns', 'PLNS': 'Plns',
        'PINE': 'Pne', 'PNE': 'Pne',
        'PINES': 'Pnes', 'PNES': 'Pnes',
        'PRAIRIE': 'Pr', 'PR': 'Pr',
        'PORT': 'Prt', 'PRT': 'Prt',
        'PORTS': 'Prts', 'PRTS': 'Prts',
        'PASSAGE': 'Psge', 'PSGE': 'Psge',
        'POINT': 'Pt', 'PT': 'Pt',
        'POINTS': 'Pts', 'PTS': 'Pts',
        'RADIAL': 'Radl', 'RADL': 'Radl',
        'RAMP': 'Ramp', 'REST': 'Rst',
        'RIDGE': 'Rdg', 'RDG': 'Rdg',
        'RIDGES': 'Rdgs', 'RDGS': 'Rdgs',
        'ROADS': 'Rds', 'RDS': 'Rds',
        'RANCH': 'Rnch', 'RNCH': 'Rnch',
        'RAPID': 'Rpd', 'RPD': 'Rpd',
        'RAPIDS': 'Rpds', 'RPDS': 'Rpds',
        'ROUTE': 'Rte', 'RTE': 'Rte',
        'SHOAL': 'Shl', 'SHL': 'Shl',
        'SHOALS': 'Shls', 'SHLS': 'Shls',
        'SHORE': 'Shr', 'SHR': 'Shr',
        'SHORES': 'Shrs', 'SHRS': 'Shrs',
        'SKYWAY': 'Skwy', 'SKWY': 'Skwy',
        'SUMMIT': 'Smt', 'SMT': 'Smt',
        'SPRING': 'Spg', 'SPG': 'Spg',
        'SPRINGS': 'Spgs', 'SPGS': 'Spgs',
        'SQUARES': 'Sqs', 'SQS': 'Sqs',
        'STATION': 'Sta', 'STA': 'Sta',
        'STRAVENUE': 'Stra', 'STRA': 'Stra',
        'STREAM': 'Strm', 'STRM': 'Strm',
        'STREETS': 'Sts', 'STS': 'Sts',
        'THROUGHWAY': 'Trwy', 'TRWY': 'Trwy',
        'TRACE': 'Trce', 'TRCE': 'Trce',
        'TRAFFICWAY': 'Trfy', 'TRFY': 'Trfy',
        'TRAILER': 'Trlr', 'TRLR': 'Trlr',
        'TUNNEL': 'Tunl', 'TUNL': 'Tunl',
        'UNION': 'Un', 'UN': 'Un',
        'UNIONS': 'Uns', 'UNS': 'Uns',
        'UNDERPASS': 'Upas', 'UPAS': 'Upas',
        'VIEW': 'Vw',  'VIEWS': 'Vws',
        'VILLAGE': 'Vlg', 'VLG': 'Vlg',
        'VILLAGES': 'Vlgs', 'VLGS': 'Vlgs',
        'VALLEY': 'Vl', 'VLY': 'Vl',
        'VALLEYS': 'Vlys', 'VLYS': 'Vlys',
        'WAYS': 'Ways', 'VIA': 'Via',
        'WELL': 'Wl', 'WL': 'Wl',
        'WELLS': 'Wls', 'WLS': 'Wls',
        'CROSSROAD': 'Xrd', 'XRD': 'Xrd',
        'CROSSROADS': 'Xrds', 'XRDS': 'Xrds'
    };

    // Find suffix (rightmost suffix)
    let mainSuffixIdx = null;
    for (let i = parts.length - 1; i >= 0; i--) {
      if (suffixMappings[parts[i].toUpperCase()]) {
        mainSuffixIdx = i;
        break;
      }
    }

    // Find directionals
    let preDirectional = null;
    let postDirectional = null;
    let suffix = null;

    for (let i = 0; i < parts.length; i++) {
      const partUpper = parts[i].toUpperCase();

      if (i === mainSuffixIdx && suffixMappings[partUpper]) {
        suffix = suffixMappings[partUpper];
      } else if (directionalMappings[partUpper]) {
        if (mainSuffixIdx !== null) {
          if (i < mainSuffixIdx && preDirectional === null) {
            preDirectional = directionalMappings[partUpper];
          } else if (i > mainSuffixIdx && postDirectional === null) {
            postDirectional = directionalMappings[partUpper];
          }
        } else if (preDirectional === null) {
          preDirectional = directionalMappings[partUpper];
        }
      }
    }

    // Extract street name (everything that's not pre-directional, suffix, or post-directional)
    const streetNameParts = [];

    for (let i = 0; i < parts.length; i++) {
      const part = parts[i];
      const partUpper = part.toUpperCase();

      // Skip if it's the pre-directional, suffix, or post-directional we identified
      if ((preDirectional && directionalMappings[partUpper] === preDirectional &&
           !streetNameParts.some(p => directionalMappings[p.toUpperCase()] === preDirectional)) ||
          i === mainSuffixIdx ||
          (postDirectional && directionalMappings[partUpper] === postDirectional &&
           mainSuffixIdx !== null && i > mainSuffixIdx)) {
        continue;
      }

      streetNameParts.push(part);
    }

    street_pre_directional_text = preDirectional;
    street_post_directional_text = postDirectional;
    street_suffix_type = suffix;
    street_name = streetNameParts.length > 0 ? streetNameParts.join(' ') : null;
  }

  // Parse city, state, zip
  let city_name = null,
    state_code = null,
    postal_code = null;
  if (cityStateZip) {
    const m = cityStateZip.match(/^(.*)\s+([A-Z]{2})\s+(\d{5})(?:-\d{4})?$/i);
    if (m) {
      city_name = (m[1] || '').toUpperCase();
      state_code = m[2].toUpperCase();
      postal_code = m[3];
    }
  }
  if (!city_name && unAddr && unAddr.full_address) {
    const mm = unAddr.full_address.match(/,\s*([^,]+),\s*([A-Z]{2})\s+(\d{5})/);
    if (mm) {
      city_name = (mm[1] || '').toUpperCase();
      state_code = mm[2];
      postal_code = mm[3];
    }
  }

  // Township/Range/Section/Block and lat/long
  let township = null,
    range = null,
    section = null,
    block = null,
    latitude = null,
    longitude = null;
  $('table.appraisalDetailsLocation')
    .find('tr')
    .each((i, tr) => {
      const headers = $(tr).find('th');
      if (
        headers.length === 5 &&
        /Township/i.test(cleanText($(headers[0]).text()))
      ) {
        const next = $(tr).next();
        const cells = next.find('td');
        if (cells.length >= 5) {
          township = cleanText($(cells[0]).text()) || null;
          range = cleanText($(cells[1]).text()) || null;
          section = cleanText($(cells[2]).text()) || null;
          block = cleanText($(cells[3]).text()) || null;
        }
      }
      if (
        headers.length >= 3 &&
        /Municipality/i.test(cleanText($(headers[0]).text()))
      ) {
        const next = $(tr).next();
        const cells = next.find('td');
        if (cells.length >= 3) {
          latitude = parseNumber($(cells[1]).text());
          longitude = parseNumber($(cells[2]).text());
        }
      }
    });

  // Use unnormalized_address format - cannot have both parsed fields and unnormalized_address
  const unnormalizedAddr = unAddr && unAddr.full_address ? unAddr.full_address : 
    (line1 && cityStateZip ? `${line1}, ${cityStateZip}` : null);
  
  const address = {
    source_http_request: unAddr && unAddr.source_http_request ? unAddr.source_http_request : null,
    request_identifier: unAddr && unAddr.request_identifier ? unAddr.request_identifier : null,
    county_name: "Lee",
    unnormalized_address: unnormalizedAddr,
    latitude: null,
    longitude: null,
    city_name: null,
    country_code: null,
    plus_four_postal_code: null,
  };
  return address;
}

function extractTaxes($) {
  const taxes = [];
  const grid = $('#valueGrid');
  if (!grid.length) return taxes;
  grid.find('tr').each((i, tr) => {
    if (i === 0) return; // header
    const tds = $(tr).find('td');
    if (tds.length < 9) return;
    const yearText = cleanText($(tds[1]).text());
    const yearMatch = yearText.match(/(\d{4})/);
    if (!yearMatch) return;
    const tax_year = parseInt(yearMatch[1], 10);
    const just = parseNumber($(tds[2]).text());
    const land = parseNumber($(tds[3]).text());
    const market_assessed = parseNumber($(tds[4]).text());
    const capped_assessed = parseNumber($(tds[5]).text());
    const taxable = parseNumber($(tds[8]).text());

    const buildingVal =
      market_assessed != null && land != null ? market_assessed - land : null;
    const obj = {
      tax_year: tax_year || null,
      property_assessed_value_amount:
        capped_assessed != null ? capped_assessed : null,
      property_market_value_amount: just != null ? just : null,
      property_building_amount:
        buildingVal != null && buildingVal > 0
          ? Number(buildingVal.toFixed(2))
          : null,
      property_land_amount: land != null ? land : null,
      property_taxable_value_amount: taxable != null ? taxable : null,
      monthly_tax_amount: null,
      period_end_date: null,
      period_start_date: null,
    };
    taxes.push(obj);
  });
  return taxes;
}

function extractSales($) {
  const out = [];
  const salesBox = $('#SalesDetails');
  const table = salesBox.find('table.detailsTable').first();
  if (!table.length) return out;
  const rows = table.find('tr');
  rows.each((i, tr) => {
    if (i === 0) return; // header
    const tds = $(tr).find('td');
    if (!tds.length) return;
    const price = parseNumber($(tds[0]).text());
    const dateText = cleanText($(tds[1]).text());
    const dateISO = parseDateMMDDYYYY(dateText);
    if (price == null && !dateISO) return;
    out.push({
      purchase_price_amount: price != null ? price : null,
      ownership_transfer_date: dateISO || null,
    });
  });
  return out;
}

function extractFlood($) {
  let community_id = null,
    panel_number = null,
    map_version = null,
    effective_date = null,
    evacuation_zone = null,
    fema_search_url = null;
  const elev = $('#ElevationDetails');
  const table = elev.find('table.detailsTable');
  if (table.length) {
    const rows = table.find('tr');
    rows.each((i, tr) => {
      const tds = $(tr).find('td');
      if (tds.length === 5) {
        community_id = cleanText($(tds[0]).text()) || null;
        panel_number = cleanText($(tds[1]).text()) || null;
        map_version = cleanText($(tds[2]).text()) || null;
        effective_date = parseDateMMDDYYYY(cleanText($(tds[3]).text())) || null;
        evacuation_zone = cleanText($(tds[4]).text()) || null;
      }
    });
  }
  const link = elev.find('a[href*="msc.fema.gov/portal/search"]');
  if (link.length) {
    fema_search_url = link.attr('href');
    if (fema_search_url && !/^https?:/i.test(fema_search_url)) {
      fema_search_url = 'https://msc.fema.gov' + fema_search_url;
    }
    fema_search_url = encodeURI(fema_search_url);
  }
  return {
    community_id: community_id || null,
    panel_number: panel_number || null,
    map_version: map_version || null,
    effective_date: effective_date || null,
    evacuation_zone: evacuation_zone || null,
    flood_zone: null,
    flood_insurance_required: false,
    fema_search_url: fema_search_url || null,
  };
}

function extractStructure($) {
  // Read roof date from structure mapping script output
  let roofDate = null;
  try {
    const structureDataPath = path.join('owners', 'structure_data.json');
    if (fs.existsSync(structureDataPath)) {
      const structureData = readJSON(structureDataPath);
      const folioId = Object.keys(structureData)[0];
      if (folioId && structureData[folioId]) {
        roofDate = structureData[folioId].roof_date;
      }
    }
  } catch (e) {
    // Ignore errors, use null
  }

  // Architectural style
  let architectural_style_type = null;
  $('table.appraisalAttributes')
    .find('tr')
    .each((i, tr) => {
      const ths = $(tr).find('th');
      if (
        ths.length === 4 &&
        /Improvement Type/i.test(cleanText($(ths[0]).text()))
      ) {
        const impType = cleanText($(tr).next().find('td').first().text());
        if (/Ranch/i.test(impType)) architectural_style_type = 'Ranch';
      }
    });

  // Subareas: get BASE and FINISHED UPPER STORY
  let finished_base_area = null;
  let finished_upper_story_area = null;
  $('table.appraisalAttributes')
    .find('tr')
    .each((i, tr) => {
      const tds = $(tr).find('td');
      if (tds.length === 4) {
        const desc = cleanText($(tds[0]).text());
        const heated = cleanText($(tds[2]).text());
        const area = parseNumber($(tds[3]).text());
        if (/BAS\s*-\s*BASE/i.test(desc) && /^Y$/i.test(heated)) {
          finished_base_area =
            area != null ? Math.round(area) : finished_base_area;
        }
        if (
          /FUS\s*-\s*FINISHED UPPER STORY/i.test(desc) &&
          /^Y$/i.test(heated)
        ) {
          finished_upper_story_area =
            area != null ? Math.round(area) : finished_upper_story_area;
        }
      }
    });

  const structure = {
    architectural_style_type: architectural_style_type || null,
    attachment_type: null,
    exterior_wall_material_primary: null,
    exterior_wall_material_secondary: null,
    exterior_wall_condition: null,
    exterior_wall_insulation_type: null,
    flooring_material_primary: null,
    flooring_material_secondary: null,
    subfloor_material: null,
    flooring_condition: null,
    interior_wall_structure_material: null,
    interior_wall_surface_material_primary: null,
    interior_wall_surface_material_secondary: null,
    interior_wall_finish_primary: null,
    interior_wall_finish_secondary: null,
    interior_wall_condition: null,
    roof_covering_material: null,
    roof_underlayment_type: null,
    roof_structure_material: null,
    roof_design_type: null,
    roof_condition: null,
    roof_date: roofDate,
    roof_age_years: null,
    gutters_material: null,
    gutters_condition: null,
    roof_material_type: null,
    foundation_type: null,
    foundation_material: null,
    foundation_waterproofing: null,
    foundation_condition: null,
    ceiling_structure_material: null,
    ceiling_surface_material: null,
    ceiling_insulation_type: null,
    ceiling_height_average: null,
    ceiling_condition: null,
    exterior_door_material: null,
    interior_door_material: null,
    window_frame_material: null,
    window_glazing_type: null,
    window_operation_type: null,
    window_screen_material: null,
    primary_framing_material: null,
    secondary_framing_material: null,
    structural_damage_indicators: null,
  };

  if (finished_base_area != null)
    structure.finished_base_area = finished_base_area;
  if (finished_upper_story_area != null)
    structure.finished_upper_story_area = finished_upper_story_area;

  return structure;
}

function extractLot($) {
  // No reliable lot dimensions/materials in HTML; return null fields per schema allowances
  return {
    lot_type: null,
    lot_length_feet: null,
    lot_width_feet: null,
    lot_area_sqft: null,
    landscaping_features: null,
    view: null,
    fencing_type: null,
    fence_height: null,
    fence_length: null,
    driveway_material: null,
    driveway_condition: null,
    lot_condition_issues: null,
  };
}

function main() {
  console.log('Script started successfully');
  const dataDir = path.join('data');
  ensureDir(dataDir);

  // Read property_seed.json for request_identifier
  let seedData = null;
  const seedPath = 'property_seed.json';
  if (fs.existsSync(seedPath)) {
    seedData = readJSON(seedPath);
  }

  const html = fs.readFileSync('input.html', 'utf-8');
  const $ = cheerio.load(html);
  const unAddr = fs.existsSync('unnormalized_address.json')
    ? readJSON('unnormalized_address.json')
    : null;

  // Extract geometry from CSV first, then HTML
  // Three separate geometries: address (lat/long only), parcel (parcel_polygon), building (building_polygon)
  let geometries = null;
  const csvFiles = fs.readdirSync('.').filter(f => f.endsWith('.csv'));
  console.log(`Found ${csvFiles.length} CSV file(s) in current directory: ${csvFiles.join(', ')}`);
  for (const csvFile of csvFiles) {
    const requestId = seedData ? seedData.request_identifier : null;
    console.log(`Attempting to extract geometry from CSV: ${csvFile}`);
    geometries = extractGeometryFromCsv(csvFile, requestId);
    if (geometries) {
      console.log(`✓ Found geometry data in CSV: ${csvFile}`);
      if (geometries.parcelGeometry?.polygon) {
        console.log(`✓ Parcel polygon extracted with ${geometries.parcelGeometry.polygon.length} points`);
      }
      if (geometries.buildingGeometry?.polygon) {
        console.log(`✓ Building polygon extracted with ${geometries.buildingGeometry.polygon.length} points`);
      }
      break;
    }
  }
  
  // If no CSV geometry, try to extract from HTML (latitude/longitude only for address geometry)
  if (!geometries || !geometries.addressGeometry) {
    // Extract lat/long from HTML if available
    let latitude = null;
    let longitude = null;
    $('table.appraisalDetailsLocation')
      .find('tr')
      .each((i, tr) => {
        const headers = $(tr).find('th');
        if (
          headers.length >= 3 &&
          /Municipality/i.test(cleanText($(headers[0]).text()))
        ) {
          const next = $(tr).next();
          const cells = next.find('td');
          if (cells.length >= 3) {
            latitude = parseNumber($(cells[1]).text());
            longitude = parseNumber($(cells[2]).text());
          }
        }
      });
    
    if (latitude !== null || longitude !== null) {
      const requestId = seedData ? seedData.request_identifier : null;
      if (!geometries) {
        geometries = { addressGeometry: null, parcelGeometry: null, buildingGeometry: null };
      }
      geometries.addressGeometry = {
        request_identifier: requestId,
        latitude: latitude,
        longitude: longitude,
        // No polygon for address geometry
      };
    }
  }
  
  // Write three separate geometry files if found
  if (geometries) {
    const requestId = seedData ? seedData.request_identifier : null;
    
    // Address geometry: lat/long only
    if (geometries.addressGeometry) {
      if (seedData && seedData.source_http_request) {
        geometries.addressGeometry.source_http_request = seedData.source_http_request;
      }
      writeJSON(path.join(dataDir, 'geometry_address.json'), geometries.addressGeometry);
      console.log(`✓ Created geometry_address.json with latitude: ${geometries.addressGeometry.latitude}, longitude: ${geometries.addressGeometry.longitude}`);
    }
    
    // Parcel geometry: parcel_polygon only
    if (geometries.parcelGeometry) {
      if (seedData && seedData.source_http_request) {
        geometries.parcelGeometry.source_http_request = seedData.source_http_request;
      }
      writeJSON(path.join(dataDir, 'geometry_parcel.json'), geometries.parcelGeometry);
      console.log(`✓ Created geometry_parcel.json with polygon: ${geometries.parcelGeometry.polygon.length} points`);
    }
    
    // Building geometry: building_polygon only
    if (geometries.buildingGeometry) {
      if (seedData && seedData.source_http_request) {
        geometries.buildingGeometry.source_http_request = seedData.source_http_request;
      }
      writeJSON(path.join(dataDir, 'geometry_building.json'), geometries.buildingGeometry);
      console.log(`✓ Created geometry_building.json with polygon: ${geometries.buildingGeometry.polygon.length} points`);
    }
  }

  // Property
  const property = extractProperty($);
  writeJSON(path.join(dataDir, 'property.json'), property);

  // Parcel - create parcel.json with parcel_identifier from property
  if (property.parcel_identifier) {
    const parcel = {
      source_http_request: seedData && seedData.source_http_request ? seedData.source_http_request : null,
      request_identifier: seedData ? seedData.request_identifier : null,
      parcel_identifier: property.parcel_identifier,
    };
    writeJSON(path.join(dataDir, 'parcel.json'), parcel);
    console.log(`✓ Created parcel.json with parcel_identifier: ${property.parcel_identifier}`);
  }

  // Address
  const address = extractAddress($, unAddr);
  writeJSON(path.join(dataDir, 'address.json'), address);

  // Taxes
  const taxes = extractTaxes($);
  taxes.forEach((t, idx) => {
    const year = t.tax_year || `idx_${idx + 1}`;
    writeJSON(path.join(dataDir, `tax_${year}.json`), t);
  });

  // Sales
  const salesList = extractSales($);
  salesList.forEach((s, idx) => {
    writeJSON(path.join(dataDir, `sales_${idx + 1}.json`), s);
  });

  // Flood
  const flood = extractFlood($);
  writeJSON(path.join(dataDir, 'flood_storm_information.json'), flood);

  // Utilities from owners/utilities_data.json
  if (fs.existsSync(path.join('owners', 'utilities_data.json'))) {
    const utilitiesData = readJSON(path.join('owners', 'utilities_data.json'));
    // Key: property_*
    let util = null;
    const key = Object.keys(utilitiesData).find((k) => /property_/.test(k));
    if (key) util = utilitiesData[key];
    if (util) {
      writeJSON(path.join(dataDir, 'utility.json'), {
        cooling_system_type: util.cooling_system_type ?? null,
        heating_system_type: util.heating_system_type ?? null,
        public_utility_type: util.public_utility_type ?? null,
        sewer_type: util.sewer_type ?? null,
        water_source_type: util.water_source_type ?? null,
        plumbing_system_type: util.plumbing_system_type ?? null,
        plumbing_system_type_other_description:
          util.plumbing_system_type_other_description ?? null,
        electrical_panel_capacity: util.electrical_panel_capacity ?? null,
        electrical_wiring_type: util.electrical_wiring_type ?? null,
        hvac_condensing_unit_present: util.hvac_condensing_unit_present ?? null,
        electrical_wiring_type_other_description:
          util.electrical_wiring_type_other_description ?? null,
        solar_panel_present: !!util.solar_panel_present,
        solar_panel_type: util.solar_panel_type ?? null,
        solar_panel_type_other_description:
          util.solar_panel_type_other_description ?? null,
        smart_home_features: util.smart_home_features ?? null,
        smart_home_features_other_description:
          util.smart_home_features_other_description ?? null,
        hvac_unit_condition: util.hvac_unit_condition ?? null,
        solar_inverter_visible: !!util.solar_inverter_visible,
        hvac_unit_issues: util.hvac_unit_issues ?? null,
      });
    }
  }

  // Check HTML for building references to create building layout
  let hasBuilding = false;
  const htmlText = $('body').text().toLowerCase();
  if (/building|structure|dwelling|residence|house/i.test(htmlText)) {
    hasBuilding = true;
  }
  
  // Layouts from owners/layout_data.json
  let layoutCount = 0;
  if (fs.existsSync(path.join('owners', 'layout_data.json'))) {
    const layoutData = readJSON(path.join('owners', 'layout_data.json'));
    const key = Object.keys(layoutData).find((k) => /property_/.test(k));
    if (key && layoutData[key] && Array.isArray(layoutData[key].layouts)) {
      layoutData[key].layouts.forEach((lay, idx) => {
        layoutCount++;
        // Generate space_type_index: format is "spaceTypeIndex.spaceIndex" or just "spaceIndex"
        // Pattern must be: ^\d+(\.\d+)?(\.\d+)?$
        let spaceTypeIndex = null;
        if (lay.space_index !== null && lay.space_index !== undefined) {
          // If space_index is provided, use it as the base
          spaceTypeIndex = String(lay.space_index);
        } else if (idx !== null && idx !== undefined) {
          // Fallback to array index + 1
          spaceTypeIndex = String(idx + 1);
        }
        
        const out = {
          space_type: normalizeSpaceType(lay.space_type),
          space_index: lay.space_index ?? null,
          space_type_index: spaceTypeIndex,
          flooring_material_type: lay.flooring_material_type ?? null,
          size_square_feet: lay.size_square_feet ?? null,
          floor_level: lay.floor_level ?? null,
          has_windows: lay.has_windows ?? null,
          window_design_type: lay.window_design_type ?? null,
          window_material_type: lay.window_material_type ?? null,
          window_treatment_type: lay.window_treatment_type ?? null,
          is_finished: lay.is_finished !== null && lay.is_finished !== undefined ? Boolean(lay.is_finished) : true,
          furnished: lay.furnished ?? null,
          paint_condition: lay.paint_condition ?? null,
          flooring_wear: lay.flooring_wear ?? null,
          clutter_level: lay.clutter_level ?? null,
          visible_damage: lay.visible_damage ?? null,
          countertop_material: lay.countertop_material ?? null,
          cabinet_style: lay.cabinet_style ?? null,
          fixture_finish_quality: lay.fixture_finish_quality ?? null,
          design_style: lay.design_style ?? null,
          natural_light_quality: lay.natural_light_quality ?? null,
          decor_elements: lay.decor_elements ?? null,
          pool_type: lay.pool_type ?? null,
          pool_equipment: lay.pool_equipment ?? null,
          spa_type: lay.spa_type ?? null,
          safety_features: lay.safety_features ?? null,
          view_type: lay.view_type ?? null,
          lighting_features: lay.lighting_features ?? null,
          condition_issues: lay.condition_issues ?? null,
          is_exterior: lay.is_exterior ?? false,
          pool_condition: lay.pool_condition ?? null,
          pool_surface_type: lay.pool_surface_type ?? null,
          pool_water_quality: lay.pool_water_quality ?? null,
        };
        writeJSON(path.join(dataDir, `layout_${idx + 1}.json`), out);
      });
    }
  }
  
  // Create building layout if building is detected in HTML
  let buildingLayoutFile = null;
  if (hasBuilding) {
    const buildingLayout = {
      space_type: 'Building',
      space_index: layoutCount + 1,
      space_type_index: String(layoutCount + 1),
      flooring_material_type: null,
      size_square_feet: null,
      floor_level: null,
      has_windows: null,
      window_design_type: null,
      window_material_type: null,
      window_treatment_type: null,
      is_finished: true, // Required boolean - building is finished
      furnished: null,
      paint_condition: null,
      flooring_wear: null,
      clutter_level: null,
      visible_damage: null,
      countertop_material: null,
      cabinet_style: null,
      fixture_finish_quality: null,
      design_style: null,
      natural_light_quality: null,
      decor_elements: null,
      pool_type: null,
      pool_equipment: null,
      spa_type: null,
      safety_features: null,
      view_type: null,
      lighting_features: null,
      condition_issues: null,
      is_exterior: false, // Required boolean - building is interior
      pool_condition: null,
      pool_surface_type: null,
      pool_water_quality: null,
    };
    buildingLayoutFile = `layout_${layoutCount + 1}.json`;
    writeJSON(path.join(dataDir, buildingLayoutFile), buildingLayout);
    console.log(`✓ Created building layout: ${buildingLayoutFile}`);
  }

  // Owners from owners/owner_data.json (single type only). Prefer company.
  let salesFiles = [];
  const dataFiles = fs.readdirSync(dataDir);
  salesFiles = dataFiles
    .filter((f) => /^sales_\d+\.json$/.test(f))
    .sort((a, b) => {
      const ai = parseInt(a.match(/(\d+)/)[1], 10);
      const bi = parseInt(b.match(/(\d+)/)[1], 10);
      return ai - bi;
    });

  if (fs.existsSync(path.join('owners', 'owner_data.json'))) {
    const ownerData = readJSON(path.join('owners', 'owner_data.json'));
    const key = Object.keys(ownerData).find((k) => /property_/.test(k));
    let currentOwners = [];
    if (
      key &&
      ownerData[key] &&
      ownerData[key].owners_by_date &&
      ownerData[key].owners_by_date.current
    ) {
      currentOwners = ownerData[key].owners_by_date.current;
    }
    const companies = currentOwners.filter((o) => o.type === 'company');
    const persons = currentOwners.filter((o) => o.type === 'person');

    if (companies.length > 0) {
      const c = companies[0];
      writeJSON(path.join(dataDir, 'company_1.json'), { name: c.name ?? null });
    } else if (persons.length > 0) {
      const p = persons[0];
      writeJSON(path.join(dataDir, 'person_1.json'), {
        birth_date: null,
        first_name: p.first_name || null,
        last_name: p.last_name || null,
        middle_name: p.middle_name ?? null,
        prefix_name: null,
        suffix_name: null,
        us_citizenship_status: null,
        veteran_status: null,
      });
    }

    // Relationships: link to most recent sale (first parsed sale row is typically most recent)
    if (salesFiles.length > 0) {
      if (fs.existsSync(path.join(dataDir, 'company_1.json'))) {
        writeJSON(path.join(dataDir, 'relationship_sales_company.json'), {
          to: { '/': './company_1.json' },
          from: { '/': './sales_1.json' },
        });
      } else if (fs.existsSync(path.join(dataDir, 'person_1.json'))) {
        writeJSON(path.join(dataDir, 'relationship_sales_person.json'), {
          to: { '/': './person_1.json' },
          from: { '/': './sales_1.json' },
        });
      }
    }
  }

  // Structure
  const structure = extractStructure($);
  writeJSON(path.join(dataDir, 'structure.json'), structure);

  // Lot
  const lot = extractLot($);
  writeJSON(path.join(dataDir, 'lot.json'), lot);

  // Property relationships - County schema requires these
  const propertyPath = path.join(dataDir, 'property.json');
  const addressPath = path.join(dataDir, 'address.json');
  const lotPath = path.join(dataDir, 'lot.json');
  const floodPath = path.join(dataDir, 'flood_storm_information.json');
  const structurePath = path.join(dataDir, 'structure.json');
  const utilityPath = path.join(dataDir, 'utility.json');
  
  // property_has_address (singleton)
  if (fs.existsSync(propertyPath) && fs.existsSync(addressPath)) {
    writeJSON(path.join(dataDir, 'relationship_property_address.json'), {
      from: { '/': './property.json' },
      to: { '/': './address.json' },
    });
    console.log('✓ Created relationship_property_address.json');
  }
  
  // property_has_lot (singleton)
  if (fs.existsSync(propertyPath) && fs.existsSync(lotPath)) {
    writeJSON(path.join(dataDir, 'relationship_property_lot.json'), {
      from: { '/': './property.json' },
      to: { '/': './lot.json' },
    });
    console.log('✓ Created relationship_property_lot.json');
  }
  
  // property_has_tax (array)
  const taxFiles = dataFiles.filter((f) => /^tax_\d+\.json$/.test(f)).sort();
  taxFiles.forEach((taxFile, idx) => {
    writeJSON(path.join(dataDir, `relationship_property_tax_${idx + 1}.json`), {
      from: { '/': './property.json' },
      to: { '/': `./${taxFile}` },
    });
  });
  if (taxFiles.length > 0) {
    console.log(`✓ Created ${taxFiles.length} property_tax relationship(s)`);
  }
  
  // property_has_sales_history (array)
  salesFiles.forEach((salesFile, idx) => {
    writeJSON(path.join(dataDir, `relationship_property_sales_${idx + 1}.json`), {
      from: { '/': './property.json' },
      to: { '/': `./${salesFile}` },
    });
  });
  if (salesFiles.length > 0) {
    console.log(`✓ Created ${salesFiles.length} property_sales relationship(s)`);
  }
  
  // property_has_layout (array) - include building layout if created
  let layoutFiles = dataFiles.filter((f) => /^layout_\d+\.json$/.test(f)).sort((a, b) => {
    const ai = parseInt(a.match(/(\d+)/)[1], 10);
    const bi = parseInt(b.match(/(\d+)/)[1], 10);
    return ai - bi;
  });
  
  // If building layout was created, ensure it's in the list (it should be, but double-check)
  if (buildingLayoutFile && !layoutFiles.includes(buildingLayoutFile)) {
    layoutFiles.push(buildingLayoutFile);
    layoutFiles.sort((a, b) => {
      const ai = parseInt(a.match(/(\d+)/)[1], 10);
      const bi = parseInt(b.match(/(\d+)/)[1], 10);
      return ai - bi;
    });
  }
  layoutFiles.forEach((layoutFile, idx) => {
    writeJSON(path.join(dataDir, `relationship_property_layout_${idx + 1}.json`), {
      from: { '/': './property.json' },
      to: { '/': `./${layoutFile}` },
    });
  });
  if (layoutFiles.length > 0) {
    console.log(`✓ Created ${layoutFiles.length} property_layout relationship(s)`);
  }
  
  // property_has_flood_storm_information (singleton)
  if (fs.existsSync(propertyPath) && fs.existsSync(floodPath)) {
    writeJSON(path.join(dataDir, 'relationship_property_flood_storm_information.json'), {
      from: { '/': './property.json' },
      to: { '/': './flood_storm_information.json' },
    });
    console.log('✓ Created relationship_property_flood_storm_information.json');
  }
  
  // property_has_structure (singleton)
  if (fs.existsSync(propertyPath) && fs.existsSync(structurePath)) {
    writeJSON(path.join(dataDir, 'relationship_property_structure.json'), {
      from: { '/': './property.json' },
      to: { '/': './structure.json' },
    });
    console.log('✓ Created relationship_property_structure.json');
  }
  
  // property_has_utility (singleton)
  if (fs.existsSync(propertyPath) && fs.existsSync(utilityPath)) {
    writeJSON(path.join(dataDir, 'relationship_property_utility.json'), {
      from: { '/': './property.json' },
      to: { '/': './utility.json' },
    });
    console.log('✓ Created relationship_property_utility.json');
  }
  
  // parcel_has_geometry (singleton) - County schema
  // Links to geometry_parcel.json (parcel_polygon only)
  const parcelGeometryPath = path.join(dataDir, 'geometry_parcel.json');
  const parcelPath = path.join(dataDir, 'parcel.json');
  if (fs.existsSync(parcelGeometryPath) && fs.existsSync(parcelPath)) {
    writeJSON(path.join(dataDir, 'relationship_parcel_geometry.json'), {
      from: { '/': './parcel.json' },
      to: { '/': './geometry_parcel.json' },
    });
    console.log('✓ Created relationship_parcel_geometry.json');
  }
  
  // address_has_geometry (singleton) - County schema
  // Links to geometry_address.json (lat/long only, no polygon)
  const addressGeometryPath = path.join(dataDir, 'geometry_address.json');
  if (fs.existsSync(addressGeometryPath) && fs.existsSync(addressPath)) {
    writeJSON(path.join(dataDir, 'relationship_address_geometry.json'), {
      from: { '/': './address.json' },
      to: { '/': './geometry_address.json' },
    });
    console.log('✓ Created relationship_address_geometry.json');
  }
  
  // layout_has_geometry (array) - County schema (only for layouts with space_type: 'Building')
  // Links to geometry_building.json (building_polygon only)
  const buildingGeometryPath = path.join(dataDir, 'geometry_building.json');
  let buildingLayoutCount = 0;
  layoutFiles.forEach((layoutFile, idx) => {
    // Read layout file to check space_type
    const layoutPath = path.join(dataDir, layoutFile);
    if (fs.existsSync(layoutPath) && fs.existsSync(buildingGeometryPath)) {
      const layoutData = JSON.parse(fs.readFileSync(layoutPath, 'utf-8'));
      // Only create geometry relationship for Building space_type
      if (layoutData.space_type === 'Building') {
        buildingLayoutCount++;
        writeJSON(path.join(dataDir, `relationship_layout_geometry_${buildingLayoutCount}.json`), {
          from: { '/': `./${layoutFile}` },
          to: { '/': './geometry_building.json' },
        });
      }
    }
  });
  // Also check building layout if it exists and wasn't in layoutFiles
  if (buildingLayoutFile && fs.existsSync(buildingGeometryPath) && !layoutFiles.includes(buildingLayoutFile)) {
    const buildingLayoutPath = path.join(dataDir, buildingLayoutFile);
    if (fs.existsSync(buildingLayoutPath)) {
      const layoutData = JSON.parse(fs.readFileSync(buildingLayoutPath, 'utf-8'));
      if (layoutData.space_type === 'Building') {
        buildingLayoutCount++;
        writeJSON(path.join(dataDir, `relationship_layout_geometry_${buildingLayoutCount}.json`), {
          from: { '/': `./${buildingLayoutFile}` },
          to: { '/': './geometry_building.json' },
        });
        console.log(`✓ Created layout_has_geometry relationship for building layout`);
      }
    }
  }
  if (buildingLayoutCount > 0) {
    console.log(`✓ Created ${buildingLayoutCount} layout_has_geometry relationship(s) for Building space_type`);
  }
  
  // layout_has_layout - Create relationships from all layouts to building layout
  if (buildingLayoutFile && layoutFiles.length > 0) {
    layoutFiles.forEach((layoutFile, idx) => {
      // Skip if this is the building layout itself
      if (layoutFile !== buildingLayoutFile) {
        writeJSON(path.join(dataDir, `relationship_layout_layout_${idx + 1}.json`), {
          from: { '/': `./${layoutFile}` },
          to: { '/': `./${buildingLayoutFile}` },
        });
      }
    });
    if (layoutFiles.length > 0) {
      console.log(`✓ Created ${layoutFiles.length} layout_has_layout relationship(s) to building layout`);
    }
  }
}

if (require.main === module) {
  main();
}
